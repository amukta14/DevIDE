// Welcome to Typescript!
const fs = require('fs');
const input = fs.readFileSync(0, 'utf-8'); // Read from stdin
console.log(input)