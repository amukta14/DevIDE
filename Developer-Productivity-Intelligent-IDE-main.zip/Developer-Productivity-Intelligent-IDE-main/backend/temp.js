// Welcome to Typescript!
var fs = require('fs');
var input = fs.readFileSync(0, 'utf-8'); // Read from stdin
console.log(input);
