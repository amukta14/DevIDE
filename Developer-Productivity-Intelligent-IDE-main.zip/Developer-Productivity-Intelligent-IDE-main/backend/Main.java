// Welcome to Java!
import java.util.Scanner;
public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    //System.out.print("Enter a number: ");
    int num = scanner.nextInt();
    System.out.println(num);
  }
}





